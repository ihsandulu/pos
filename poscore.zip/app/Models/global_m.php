<?php

namespace App\Models;

use CodeIgniter\Model;

class global_m extends Model
{
    public function ceksesi()
    {
        /*$this->session = \Config\Services::session();
        if ($this->session->get('user_id') == "") {
            header('Location:' . base_url('login'));
            exit;
        }*/
    }
}
